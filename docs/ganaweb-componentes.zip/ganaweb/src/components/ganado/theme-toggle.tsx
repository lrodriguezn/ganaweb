import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * ThemeToggle — alterna claro/oscuro agregando/quitando `dark` en <html>.
 * Spec: ganaweb-design.md v1.1 — el modo oscuro existe para el ordeño y
 * los manejos de madrugada; claro sigue siendo el default (trabajo al sol).
 *
 * La preferencia se persiste en localStorage ("ganaweb-theme"). Para
 * evitar el flash al cargar, incluir en el <head> del documento:
 *
 *   <script>
 *     if (localStorage.getItem("ganaweb-theme") === "dark")
 *       document.documentElement.classList.add("dark");
 *   </script>
 */
const STORAGE_KEY = "ganaweb-theme";
const ESTILO_KEY = "ganaweb-estilo";  // "a" (Campo) | "b" (Moderna)

export function ThemeToggle({ className }: { className?: string }) {
  const [dark, setDark] = useState<boolean>(() =>
    typeof document !== "undefined"
      ? document.documentElement.classList.contains("dark")
      : false,
  );

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      localStorage.setItem(STORAGE_KEY, dark ? "dark" : "light");
    } catch {
      /* almacenamiento no disponible: la preferencia dura la sesión */
    }
  }, [dark]);

  return (
    <button
      type="button"
      onClick={() => setDark((d) => !d)}
      aria-label={dark ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
      aria-pressed={dark}
      className={cn(
        "size-9 rounded-lg flex items-center justify-center text-muted-foreground",
        "hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
    >
      {dark ? (
        <Sun aria-hidden="true" className="size-4" />
      ) : (
        <Moon aria-hidden="true" className="size-4" />
      )}
    </button>
  );
}

/**
 * EstiloSwitcher — elegir entre las dos propuestas visuales (v1.3):
 *   A "Campo":  cálida, plana, contraste máximo bajo sol directo.
 *   B "Moderna": zinc + esmeralda, sombras suaves, radios amplios.
 * Aplica/quita `theme-b` en <html>; combinable con el modo oscuro.
 * Ubicación (pantallas 16/17 del .op): menú del AVATAR en desktop y
 * "Más → Apariencia" en mobile. NUNCA dentro del módulo Configuración:
 * ese módulo es solo-admin (RBAC) y la apariencia es una preferencia
 * personal — todo usuario, incluido el operario básico, puede elegirla.
 * Anti-flash: agregar al script del <head>:
 *   if (localStorage.getItem("ganaweb-estilo") === "b")
 *     document.documentElement.classList.add("theme-b");
 */
export function EstiloSwitcher({ className }: { className?: string }) {
  const [estilo, setEstilo] = useState<"a" | "b">(() =>
    typeof document !== "undefined" &&
    document.documentElement.classList.contains("theme-b") ? "b" : "a",
  );

  useEffect(() => {
    document.documentElement.classList.toggle("theme-b", estilo === "b");
    try { localStorage.setItem(ESTILO_KEY, estilo); } catch { /* sesión */ }
  }, [estilo]);

  const opciones = [
    { valor: "a" as const, etiqueta: "Campo" },
    { valor: "b" as const, etiqueta: "Moderna" },
  ];
  return (
    <div
      role="radiogroup"
      aria-label="Estilo visual"
      className={cn("inline-flex rounded-[10px] bg-muted p-[3px]", className)}
    >
      {opciones.map((o) => (
        <button
          key={o.valor}
          type="button"
          role="radio"
          aria-checked={estilo === o.valor}
          onClick={() => setEstilo(o.valor)}
          className={cn(
            "px-3 h-8 rounded-lg text-caption font-medium transition-colors",
            estilo === o.valor
              ? "bg-card text-primary-soft-text shadow-(--shadow-card)"
              : "text-muted-foreground",
          )}
        >
          {o.etiqueta}
        </button>
      ))}
    </div>
  );
}
