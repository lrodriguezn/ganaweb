import { useEffect, useState } from "react";
import { Check, Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * ThemeToggle — alterna claro/oscuro agregando/quitando `dark` en <html>.
 * Spec: ganaweb-design.md v1.1 — el modo oscuro existe para el ordeño y
 * los manejos de madrugada; claro sigue siendo el default (trabajo al sol).
 *
 * La preferencia se persiste en localStorage ("ganaweb-theme"). Para
 * evitar el flash al cargar, incluir en el <head> del documento:
 *
 *   <script>
 *     if (localStorage.getItem("ganaweb-theme") === "dark")
 *       document.documentElement.classList.add("dark");
 *   </script>
 */
const STORAGE_KEY = "ganaweb-theme";
const ESTILO_KEY = "ganaweb-estilo";  // "a" (Campo) | "b" (Moderna)

export function ThemeToggle({ className }: { className?: string }) {
  const [dark, setDark] = useState<boolean>(() =>
    typeof document !== "undefined"
      ? document.documentElement.classList.contains("dark")
      : false,
  );

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      localStorage.setItem(STORAGE_KEY, dark ? "dark" : "light");
    } catch {
      /* almacenamiento no disponible: la preferencia dura la sesión */
    }
  }, [dark]);

  return (
    <button
      type="button"
      onClick={() => setDark((d) => !d)}
      aria-label={dark ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
      aria-pressed={dark}
      className={cn(
        "size-9 rounded-lg flex items-center justify-center text-muted-foreground",
        "hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
    >
      {dark ? (
        <Sun aria-hidden="true" className="size-4" />
      ) : (
        <Moon aria-hidden="true" className="size-4" />
      )}
    </button>
  );
}

/**
 * EstiloSelector — el usuario elige entre los 5 estilos del catálogo
 * (ganaweb-estilos.md). v1.4: reemplaza al EstiloSwitcher de 2 pills,
 * que no escalaba. Grilla de cards con preview de paleta + check.
 * Ubicación: "Apariencia" en menú del avatar (desktop) y "Más" (mobile).
 * Anti-flash en el <head>:
 *   var e = localStorage.getItem("ganaweb-estilo");
 *   if (e && e !== "campo") document.documentElement.classList.add("theme-" + e);
 */
export const ESTILOS = [
  { id: "campo",   nombre: "Campo",   desc: "Contraste máximo al sol",
    preview: ["#FAF8F4", "#2F6B3F", "#E4F0E7"] },
  { id: "moderna", nombre: "Moderna", desc: "Esmeralda con gradiente",
    preview: ["#F4F5F7", "#059669", "#10B981"] },
  { id: "indigo",  nombre: "Índigo",  desc: "SaaS clásico",
    preview: ["#F5F5FA", "#4F46E5", "#7C3AED"] },
  { id: "cielo",   nombre: "Cielo",   desc: "Azul agro-tech",
    preview: ["#F3F6F9", "#0284C7", "#06B6D4"] },
  { id: "grafito", nombre: "Grafito", desc: "Sobrio con ámbar",
    preview: ["#F5F5F4", "#1C1917", "#F59E0B"] },
] as const;
export type EstiloId = (typeof ESTILOS)[number]["id"];

const THEME_CLASSES = ESTILOS.filter((e) => e.id !== "campo")
  .map((e) => `theme-${e.id}`);

function aplicarEstilo(id: EstiloId) {
  const html = document.documentElement;
  THEME_CLASSES.forEach((c) => html.classList.remove(c));
  if (id !== "campo") html.classList.add(`theme-${id}`);
}

export function EstiloSelector({ className }: { className?: string }) {
  const [estilo, setEstilo] = useState<EstiloId>(() => {
    if (typeof document === "undefined") return "campo";
    const activo = ESTILOS.find((e) =>
      document.documentElement.classList.contains(`theme-${e.id}`));
    return activo?.id ?? "campo";
  });

  useEffect(() => {
    aplicarEstilo(estilo);
    try { localStorage.setItem(ESTILO_KEY, estilo); } catch { /* sesión */ }
  }, [estilo]);

  return (
    <div role="radiogroup" aria-label="Estilo visual"
         className={cn("grid grid-cols-2 sm:grid-cols-3 gap-2", className)}>
      {ESTILOS.map((e) => {
        const activo = estilo === e.id;
        return (
          <button key={e.id} type="button" role="radio" aria-checked={activo}
            onClick={() => setEstilo(e.id)}
            className={cn(
              "rounded-card border bg-card p-3 text-left min-h-[--h-touch]",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              activo ? "border-primary ring-1 ring-primary" : "hover:bg-muted/50",
            )}>
            <span className="flex items-center gap-1 mb-1.5">
              {e.preview.map((c, i) => (
                <span key={i} aria-hidden="true"
                  className="size-3.5 rounded-full border border-black/10"
                  style={{ backgroundColor: c }} />
              ))}
              {activo && <Check aria-hidden="true" className="size-3.5 ms-auto text-pasto-600" />}
            </span>
            <span className="block text-caption font-medium text-foreground">{e.nombre}</span>
            <span className="block text-[10px] text-muted-foreground">{e.desc}</span>
          </button>
        );
      })}
    </div>
  );
}
